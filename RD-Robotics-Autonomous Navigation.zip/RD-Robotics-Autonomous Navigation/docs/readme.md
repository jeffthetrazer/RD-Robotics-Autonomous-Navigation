Assumptions:
The robot operates in a 2D rectangular warehouse.
Obstacles are placed randomly and are at least 1 meter apart.
The robot can detect obstacles within 0.2 meters.
Linear velocity is 1 m/s, and angular velocity is 3 rad/s.
The robot starts from position (0, 0) with an orientation of 0 radians.

Limitations:
No global path planning algorithm is used, so the robot might take longer routes.
The obstacle detection and avoidance mechanism only work when obstacles are within the robot's sensor range of 0.2 meters.
The simulation assumes a 10x10 meter warehouse and does not account for walls or other boundary conditions.

Future Work:
Path Planning: Implementing global path planning algorithms like A* or Dijkstra's to optimize the robot's route in the warehouse.
Better Obstacle Detection: Improving the sensor model and range for detecting obstacles further away and adding multiple sensor types (e.g.camera-based detection).
PID Control: Introducing PID control to refine movements and obstacle avoidance strategies, making the robot's movements smoother.

Instructions for running the program:

1.Install pythin dependencies by running :
  pip install numpy

2.Run the program by executing
  python src/robot_navigation.py
  
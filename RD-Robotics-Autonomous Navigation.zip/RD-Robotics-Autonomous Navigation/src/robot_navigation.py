'''src\
    Assignment done by : Ravi Prakash SIngh
    email id : raviprakash202000@gmail.com
    '''

import numpy as np
import time

# Constants
WHEEL_DIAMETER = 0.1  # meters
ROBOT_WIDTH = 0.3     # meters (distance between wheels)
LINEAR_VELOCITY = 1.0 # meters per second
ANGULAR_VELOCITY = 3.0 # radians per second
OBSTACLE_DISTANCE_THRESHOLD = 0.2 # meters (sensor range)
TIME_STEP = 0.1 # simulation time step in seconds

# Robot state
class Robot:
    def __init__(self, position, orientation):
        self.position = np.array(position, dtype=float)  # [x, y] position in meters
        self.orientation = orientation      # orientation in radians
    
    def move_forward(self, velocity, time_step):
        """Move forward in the current orientation"""
        delta_x = velocity * np.cos(self.orientation) * time_step
        delta_y = velocity * np.sin(self.orientation) * time_step
        self.position += np.array([delta_x, delta_y])

    def rotate(self, angular_velocity, time_step):
        """Rotate the robot by a certain angular velocity"""
        self.orientation += angular_velocity * time_step

    def get_position(self):
        return self.position

    def get_orientation(self):
        return self.orientation

# Function to detect obstacles
def detect_obstacle(robot_position, obstacles):
    for obs in obstacles:
        distance = np.linalg.norm(robot_position - obs)
        if distance < OBSTACLE_DISTANCE_THRESHOLD:
            return True, obs
    return False, None

# Decision making algorithm
def navigate(robot, obstacles, time_step):
    for _ in range(20):  # Run for 20 iterations
        # Detect if an obstacle is nearby
        obstacle_detected, obstacle_position = detect_obstacle(robot.get_position(), obstacles)
        
        if obstacle_detected:
            print(f"Obstacle detected at {obstacle_position}, taking evasive action!")
            robot.rotate(ANGULAR_VELOCITY, time_step)
            robot.move_forward(LINEAR_VELOCITY, time_step)
        else:
            robot.move_forward(LINEAR_VELOCITY, time_step)

        print(f"Robot's current position: {robot.get_position()}")
        time.sleep(time_step)

# Example setup of obstacles
def setup_warehouse():
    # Place 10 obstacles at random positions with at least 1m apart
    obstacles = np.random.rand(10, 2) * 10  # Random positions in a 10x10 meter grid
    return obstacles

# Main program
if __name__ == "__main__":
    # Initialize robot at starting position (0,0) with orientation 0 radians
    robot = Robot(position=[0, 0], orientation=0)
    
    # Setup warehouse with obstacles
    obstacles = setup_warehouse()
    print(f"Obstacles at: {obstacles}")

    # Start navigation loop
    navigate(robot, obstacles, TIME_STEP)
